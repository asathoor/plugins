# Fontawesome plugin for WordPress

This plugin will add Fontawesome via the standard CDN.

## Installation

Zip the files in the fontawesome directory. Then install the plugin via the WP Dashboard.

## Usage

Add the font awesome spans to a costum HTML field. And style ad libitum. Here are a few samples from W3 Schools:

~~~~
<i class="fa fa-car"></i>
<i class="fa fa-car" style="font-size:48px;"></i>
<i class="fa fa-car" style="font-size:60px;color:red;"></i>
<i class="fa fa-car" class="red"></i>
~~~~
