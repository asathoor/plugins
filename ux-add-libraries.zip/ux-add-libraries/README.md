# Will add jQuery to WordPress

The plugin will add jQuery and Animate.css to your theme. Then you may add all sorts of effects, like this:

**Important: Run jQuery in protected mode**

Sample script, add this in a custom HTML field:

~~~~
<script>
/**
 * jQuery in protected mode
 */
( function( $ ) {
	// hello world variant
	$('h1').text('I\'m a poor lonesome cowboy');
	$('h1').hover( function(){
		$(this).addClass('animated swing');
	} );
} )( jQuery ); // jquery end
</script>
~~~~
